# Maze Survival Trial — source scaffold

This ZIP is a **starter scaffold**, not a completed implementation of the full PRD. It contains a native Android/libGDX launcher, a minimal title screen, round-target data, a small HP model, and starter JVM tests.

## Prerequisites
- JDK 17 (recommended for the Android Gradle plugin used here)
- Android SDK Platform 35 and Android build tools
- Gradle wrapper generated locally or a compatible Gradle installation
- Network access for Maven/Gradle dependencies

## Build
The Gradle wrapper files are not bundled because they could not be verified in the creation environment. With Gradle installed, run:

```bash
gradle :core:test
gradle :android:assembleDebug
```

Expected APK path if the build succeeds: `android/build/outputs/apk/debug/android-debug.apk`.

## Current status
- Included: project skeleton, Android launcher, minimal libGDX title screen, exact round target table, basic HP rules, starter tests.
- Not yet implemented: full 3D maze generation/rendering, controls and camera, gem supply/collection, enemy AI and spawning, combat timers, escape/elimination, all overlays, persistence, audio, full validation and acceptance suite.
- No build or device runtime verification has been performed for this ZIP.
