package app.mazegame.trial

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class PlayerHealthTest {
    @Test fun damageConsumesTemporaryHpFirst() {
        val hp = PlayerHealth(); hp.grantTemp(50); hp.applyDamage(60)
        assertEquals(90, hp.baseHp); assertEquals(0, hp.tempHp); assertEquals(90, hp.totalHp)
    }
    @Test fun tempHpCannotExceedCap() {
        val hp = PlayerHealth(); hp.grantTemp(100)
        assertEquals(150, hp.totalHp); assertTrue(hp.totalHp <= 150)
    }
}
