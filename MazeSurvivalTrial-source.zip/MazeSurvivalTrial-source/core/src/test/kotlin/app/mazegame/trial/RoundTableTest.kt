package app.mazegame.trial

import kotlin.test.Test
import kotlin.test.assertEquals

class RoundTableTest {
    @Test fun targetsMatchSpecification() {
        assertEquals(listOf(100,125,155,195,245,305,385,480,600,750,800,1000,1250,1565,1955,2445,3055,3820,4775,5000), RoundTable.allTargets())
        for (round in 1..20) assertEquals(RoundTable.target(round) + 100, RoundTable.maxGemSupply(round))
    }
}
