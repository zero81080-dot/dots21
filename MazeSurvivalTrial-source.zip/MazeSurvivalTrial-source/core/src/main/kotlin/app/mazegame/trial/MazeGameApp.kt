package app.mazegame.trial

import com.badlogic.gdx.Game
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.OrthographicCamera
import com.badlogic.gdx.utils.ScreenUtils
import com.badlogic.gdx.utils.viewport.FitViewport
import com.badlogic.gdx.scenes.scene2d.Stage
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.scenes.scene2d.ui.Table
import com.badlogic.gdx.scenes.scene2d.ui.TextButton
import com.badlogic.gdx.scenes.scene2d.ui.Skin
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener
import com.badlogic.gdx.scenes.scene2d.InputEvent
import com.badlogic.gdx.scenes.scene2d.ui.TextButton.TextButtonStyle
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont.BitmapFontData
import com.badlogic.gdx.graphics.g2d.NinePatch
import com.badlogic.gdx.scenes.scene2d.utils.Drawable
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable

/** Minimal boot/title scaffold. Gameplay systems are not yet fully implemented. */
class MazeGameApp : Game() {
    override fun create() { setScreen(TitleScreen()) }
}

private class TitleScreen : com.badlogic.gdx.ScreenAdapter() {
    private val batch = SpriteBatch()
    private val font = BitmapFont()
    private val camera = OrthographicCamera()
    private val viewport = FitViewport(800f, 450f, camera)
    private val stage = Stage(viewport, batch)
    private val pixmap = Pixmap(1, 1, Pixmap.Format.RGBA8888).apply { setColor(Color(0.12f, 0.13f, 0.14f, 1f)); fill() }
    private val texture = Texture(pixmap).also { pixmap.dispose() }
    private val skin = Skin().apply {
        add("default-font", font)
        add("button", TextureRegionDrawable(TextureRegion(texture)))
        val style = TextButtonStyle().apply {
            up = get("button", Drawable::class.java)
            down = get("button", Drawable::class.java)
            font = this@TitleScreen.font
            fontColor = Color.WHITE
        }
        add("default", style)
        add("default", Label.LabelStyle(font, Color.WHITE))
    }

    init {
        val root = Table().apply { setFillParent(true); pad(24f) }
        root.add(Label("MAZE SURVIVAL TRIAL", skin)).padBottom(24f).row()
        root.add(Label("Native Android 3D maze-survival trial scaffold", skin)).padBottom(18f).row()
        root.add(TextButton("PLAY (prototype placeholder)", skin)).width(280f).height(56f).row()
        root.add(Label("Gameplay implementation is incomplete in this source bundle.", skin)).padTop(20f).row()
        stage.addActor(root)
        Gdx.input.inputProcessor = stage
    }

    override fun render(delta: Float) {
        ScreenUtils.clear(0.025f, 0.03f, 0.035f, 1f, true)
        stage.act(delta.coerceAtMost(1f / 20f))
        stage.draw()
    }
    override fun resize(width: Int, height: Int) = viewport.update(width, height, true)
    override fun dispose() { stage.dispose(); skin.dispose(); texture.dispose(); batch.dispose(); font.dispose() }
}
