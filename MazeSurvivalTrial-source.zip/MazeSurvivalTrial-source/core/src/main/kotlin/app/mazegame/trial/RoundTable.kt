package app.mazegame.trial

object RoundTable {
    private val targets = intArrayOf(
        100, 125, 155, 195, 245, 305, 385, 480, 600, 750,
        800, 1000, 1250, 1565, 1955, 2445, 3055, 3820, 4775, 5000
    )

    fun target(round: Int): Int = targets.getOrElse(round - 1) {
        require(round in 1..20) { "Round must be between 1 and 20" }
        0
    }

    fun maxGemSupply(round: Int): Int = target(round) + 100
    fun allTargets(): List<Int> = targets.toList()
}
