package app.mazegame.trial

data class PlayerHealth(
    var baseHp: Int = 100,
    var tempHp: Int = 0,
    val totalCap: Int = 150
) {
    val totalHp: Int get() = baseHp + tempHp
    val isDead: Boolean get() = baseHp <= 0

    fun applyDamage(amount: Int) {
        require(amount >= 0)
        val fromTemp = minOf(tempHp, amount)
        tempHp -= fromTemp
        baseHp = (baseHp - (amount - fromTemp)).coerceAtLeast(0)
    }

    fun grantTemp(amount: Int) {
        require(amount >= 0)
        tempHp = (tempHp + amount).coerceAtMost((totalCap - baseHp).coerceAtLeast(0))
    }

    fun decayTemp(amount: Int = 20) { tempHp = (tempHp - amount).coerceAtLeast(0) }
    fun resetForRound() { baseHp = 100; tempHp = 0 }
}
