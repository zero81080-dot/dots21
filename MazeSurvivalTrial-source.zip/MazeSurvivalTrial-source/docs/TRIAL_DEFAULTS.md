# Trial defaults

This scaffold does not yet implement the full TrialDefaults module from the master specification. Intended defaults to preserve during implementation include: minSdk 26, landscape orientation, maze size 24×24, base HP 100, total HP cap 150, temporary HP decay of up to 20 per 30 seconds, and the specified AMB/NEW defaults in the source specification.
