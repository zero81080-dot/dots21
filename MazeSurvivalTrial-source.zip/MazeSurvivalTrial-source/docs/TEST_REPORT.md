# Test report

No Gradle tests, Android APK build, emulator install, or device runtime tests have been run for this source bundle. The included tests are starter tests only and must be executed in a configured Android/Gradle environment.
