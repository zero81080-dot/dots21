# Progress

- Created starter multi-module Gradle Kotlin DSL project.
- Added Android launcher and minimal libGDX title screen.
- Added exact 20-round target table and max supply helper.
- Added basic player HP model and starter JVM tests.
- Build/test status: NOT RUN in this environment.
- Android runtime status: NOT VERIFIED.
