# Interfaces

Current starter interfaces are limited to `RoundTable` and `PlayerHealth`. The full SessionCommands / SessionSnapshot contracts and gameplay system boundaries remain to be implemented.
