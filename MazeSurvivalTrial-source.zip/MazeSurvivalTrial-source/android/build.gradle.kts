plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "app.mazegame.trial.android"
    compileSdk = 35
    defaultConfig {
        applicationId = "app.mazegame.trial"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-trial"
    }
}

dependencies {
    implementation(project(":core"))
    implementation("com.badlogicgames.gdx:gdx-backend-android:1.13.1")
}
